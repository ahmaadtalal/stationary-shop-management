package BO;

/**
 *
 * @author Anas
 */
public class Sale extends OperationOnProduct {

    private double totalAmount;

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }
}
