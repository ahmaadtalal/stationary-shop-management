package BO;


public class Damage extends OperationOnProduct {
    
    private String cause;

    public String getCause() {
        return cause;
    }

    public void setCause(String cause) {
        this.cause = cause;
    }
}
