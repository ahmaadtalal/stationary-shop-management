package UI;

/**
 *
 * @author Anas
 */
public class MyException extends Exception {

    public MyException(String s) {
        super(s);
    }
}
